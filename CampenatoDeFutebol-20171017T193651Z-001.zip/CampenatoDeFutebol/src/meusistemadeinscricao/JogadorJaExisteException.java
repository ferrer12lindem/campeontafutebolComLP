package meusistemadeinscricao;

public class JogadorJaExisteException extends Exception {

private static final long SerilVersionUID = 1L;
	
	public JogadorJaExisteException(String msg){
		super(msg);
	}
}
