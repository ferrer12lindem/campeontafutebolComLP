package meusistemadeinscricao;

public class ClubeNaoCadastradoException extends Exception {
/**
	 * 
	 */	
	private static final long SerilVersionUID = 1L;
	
	public ClubeNaoCadastradoException(String msg){
		super(msg);
	}

}
