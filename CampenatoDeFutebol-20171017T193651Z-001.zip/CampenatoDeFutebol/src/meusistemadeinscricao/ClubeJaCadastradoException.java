package meusistemadeinscricao;

public class ClubeJaCadastradoException extends Exception {

	private static long serialVersionUID = 1L;
	
	public ClubeJaCadastradoException(String msg){
		super(msg);
	}
}
