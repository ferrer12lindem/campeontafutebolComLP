package meusistemadeinscricao;

public class JogadorNaoExisteException extends Exception {
/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public JogadorNaoExisteException(String msg){
		super(msg);
	}
}
