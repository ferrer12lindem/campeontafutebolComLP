package meusistemadeinscricao;

public class LimiteExcedidoException extends Exception {

private static final long SerilVersionUID = 1L;
	
	public LimiteExcedidoException(String msg){
		super(msg);
	}
}
